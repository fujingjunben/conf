local vim = vim
vim.api.nvim_command('echomsg "NOTICE: \\"nvim_lsp\\" module was renamed to \\"lspconfig\\". Update your config/plugins to require(\\"lspconfig\\") instead of require(\\"nvim_lsp\\")."')
