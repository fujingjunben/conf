"""
Import the sub-packages
"""

from .patch import rifle
from .patch import ueberzug
from .patch import ui
from .patch import viewmiller
from .patch import action
from .patch import directory
from .patch import loader
from .patch import statusbar
from .patch import ccommands
from .patch import shutil_generatorized
