---
name: Pull Request
about: Submit a pull request
title: ''
---

<!--
If you want to make changes to the README.md, do so in scripts/README_template.md.
The README.md is auto-generated with all the options from the various LSP configurations.
-->
